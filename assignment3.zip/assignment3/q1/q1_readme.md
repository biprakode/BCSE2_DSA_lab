Generic implementation of Stack & Queue in C using void* pointers

1) Open user.c
2) define a new struct or use any default data type
3) Define the input & ouput functions of selected datatype
4) in main() call stack_main() & queue_main() passing sizeof selected datatype & input/ouput functions

Congratulations, a generic implementation of stack & queue is ready!!

